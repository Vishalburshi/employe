package com.employe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages ="com.employe.controller")
public class EmployeeCApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeCApplication.class, args);
		System.out.println("Employee Task");
	}

}
