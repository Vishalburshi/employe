package com.employe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employe.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    
}
