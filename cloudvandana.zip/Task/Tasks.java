package com.task;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Tasks {
    public static void main(String[] args) {
        // Task 1: Create an array with the values (1, 2, 3, 4, 5, 6, 7) and shuffle it
        List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= 7; i++) {
            numbers.add(i);
        }

        // Shuffle the array
        Collections.shuffle(numbers);

        System.out.println("Shuffled Array:");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
        System.out.println("\n");

        // Task 2: Enter a Roman Number as input and convert it to an integer
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a Roman Numeral: ");
        String romanNumeral = scanner.nextLine().toUpperCase();

        int result = romanToInteger(romanNumeral);
        System.out.println("Integer value of " + romanNumeral + " is: " + result);

        // Task 3: Check if the input is a pangram
        System.out.print("Enter a sentence to check if it's a pangram: ");
        String input = scanner.nextLine().toLowerCase();
        boolean isPangram = isPangram(input);

        if (isPangram) {
            System.out.println("The input is a pangram.");
        } else {
            System.out.println("The input is not a pangram.");
        }

        scanner.close();
    }

    // Helper function to convert Roman numeral to integer
    public static int romanToInteger(String s) {
        Map<Character, Integer> romanValues = new HashMap<>();
        romanValues.put('I', 1);
        romanValues.put('V', 5);
        romanValues.put('X', 10);
        romanValues.put('L', 50);
        romanValues.put('C', 100);
        romanValues.put('D', 500);
        romanValues.put('M', 1000);

        int result = 0;
        int prevValue = 0;

        for (int i = s.length() - 1; i >= 0; i--) {
            int currentValue = romanValues.get(s.charAt(i));

            if (currentValue < prevValue) {
                result -= currentValue;
            } else {
                result += currentValue;
            }

            prevValue = currentValue;
        }

        return result;
    }

    // Helper function to check if a string is a pangram
    public static boolean isPangram(String s) {
        boolean[] alphabetCheck = new boolean[26];

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 'a' && c <= 'z') {
                alphabetCheck[c - 'a'] = true;
            }
        }

        for (boolean b : alphabetCheck) {
            if (!b) {
                return false;
            }
        }

        return true;
    }
}
