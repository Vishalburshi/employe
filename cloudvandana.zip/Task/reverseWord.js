// Function to reverse a word
function reverseWord(word) {
    return word.split('').reverse().join('');
  }
  
  // Function to reverse words in a sentence and sort them in descending order
  function reverseAndSort(sentence) {
    // Split the sentence into words
    const words = sentence.split(' ');
  
    // Reverse each word in the array
    const reversedWords = words.map(reverseWord);
  
    // Sort the reversed words in descending order
    const sortedWords = reversedWords.sort((a, b) => b.localeCompare(a));
  
    // Join the sorted words to form the final reversed and sorted sentence
    const reversedAndSortedSentence = sortedWords.join(' ');
  
    return reversedAndSortedSentence;
  }
  
  // Example usage
  const inputSentence = "This is a sunny day";
  const result = reverseAndSort(inputSentence);
  console.log(result); // Output: "shiT si a ynnus yad"
  